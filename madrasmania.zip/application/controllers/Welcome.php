<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Welcome extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('Usemodel');
		$this->load->helper(array('url', 'form'));
		$this->load->library(array('form_validation', 'session'));
	}


	public function index()
	{
		$data['viewpage'] = "index";
		$data['categories_with_products'] = $this->Usemodel->get_selected_categories_with_products(4);
		$data["main_dishes"] = $this->Usemodel->getTodaysSpecial(8);
		$data["Tandoori_Vorspeisen"] = $this->Usemodel->getTodaysSpecial(9);
		$data["vorspeisen"] = $this->Usemodel->getTodaysSpecial(3);
		$data["Dosa_Welt"] = $this->Usemodel->getTodaysSpecial(4);
		$this->load->view('welcome_message', $data);
	}

	public function aboutus()
	{
		$data['viewpage'] = "aboutus";
		$this->load->view('welcome_message', $data);
	}

	public function contact()
	{
		$data['viewpage'] = "contact";
		$this->load->view('welcome_message', $data);
	}
	public function menu()
	{
		$data['viewpage'] = "menu";
		$data['categories_with_products'] = $this->Usemodel->get_all_categories_with_products();
		$this->load->view('welcome_message', $data);
	}
	public function gallery()
	{
		$data['viewpage'] = "gallery";
		$this->load->view('welcome_message', $data);
	}
}
