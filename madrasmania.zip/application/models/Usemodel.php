<?php
defined('BASEPATH') or exit('No direct script access allowed');


// public function get_all_categories_with_products()
// {
//     // Get all categories and their products
//     $this->db->select('category_id, category_name');
//     $this->db->from('products');
//     $categories = $this->db->get()->result_array();

//     $category_products = [];

//     // For each category, get the products
//     foreach ($categories as $category) {
//         $this->db->select('product_name, price, description, product_image');
//         $this->db->from('products');
//         $this->db->where('category_id', $category['category_id']);
//         $products = $this->db->get()->result_array();

//         if (!empty($products)) {
//             $category_products[$category['category_name']] = $products;
//         }
//     }

//     return $category_products;
// }

// public function getTodaysSpecial($category_id)
// {
//     $this->db->select('product_name, price, description, product_image');
//     $this->db->from('products');
//     $this->db->where('todayspecial', 1);
//     $this->db->where('category_id', $category_id);
//     $query = $this->db->get();
//     return $query->result_array();
// }


class Usemodel extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }



    public function get_selected_categories_with_products($limit = 4)
    {
        // Fetch 4 unique categories and their products
        $query = "
            SELECT 
                p.category_name, 
                p.product_name, 
                p.price, 
                p.description, 
                p.product_image 
            FROM 
                products p
            INNER JOIN 
                (SELECT category_name FROM products GROUP BY category_name LIMIT ?) as c
            ON 
                p.category_name = c.category_name
            ORDER BY 
                p.category_name
        ";

        $result = $this->db->query($query, array($limit))->result_array();

        $category_products = [];

        foreach ($result as $row) {
            $category_products[$row['category_name']][] = [
                'product_name' => $row['product_name'],
                'price' => $row['price'],
                'description' => $row['description'],
                'product_image' => $row['product_image']
            ];
        }

        return $category_products;
    }
    public function get_all_categories_with_products()
    {
        $this->db->select('category_id, category_name, product_name, price, description, product_image');
        $this->db->from('products');
        $categories = $this->db->get()->result_array();

        $category_products = [];

        foreach ($categories as $product) {
            $category_name = $product['category_name'];
            $category_products[$category_name][] = $product;
        }

        return $category_products;
    }

    public function getTodaysSpecial($category_id)
    {
        $this->db->select('product_name, price, description, product_image');
        $this->db->from('products');
        $this->db->where('todayspecial', 1);
        $this->db->where('category_id', $category_id);
        $query = $this->db->get();
        return $query->result_array();
    }
}
